
package util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBConnectionUtil {
    private static final String URL = "jdbc:mysql://localhost/?user=root&password=srishtyAg12@"; // Change this to your database name
    private static final String USERNAME = "root"; 
    private static final String PASSWORD = "srishtyAg12@"; 

    /**
     * Establishes a connection to the SQL Server database.
     *
     * @return Connection object
     * @throws SQLException if a database access error occurs
     */
    public static Connection getConnection() throws SQLException {
        Connection connection = DriverManager.getConnection(URL, USERNAME, PASSWORD);
        System.out.println("Connected to the database successfully.");
        return connection;
    }
}
