package util;

public class DBPropertyUtil {

    // Static method to return the database connection string
    public static String getConnectionString() {
        // Define the database connection string directly
        String host = "localhost"; 
        String port = "3306"; 
        String dbName = "financeDB"; 
        String user = "root"; 
        String password = "srishtyAg12@"; 

        // Return the complete connection string for MySQL
        return "jdbc:mysql://" + host + ":" + port + "/" + dbName + "?user=" + user + "&password=" + password;
    }
}


