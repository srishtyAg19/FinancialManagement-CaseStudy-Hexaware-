package com.hexa.test;

import entity.Expense;
import entity.User;
import exception.ExpenseNotFoundException;
import exception.UserNotFoundException;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import dao.FinanceRepositoryImpl;
import util.DBConnectionUtil;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.Date;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

public class testClass {

    private FinanceRepositoryImpl financeRepository;

    @BeforeEach
    void setUp() {
        financeRepository = new FinanceRepositoryImpl();
        // Assuming DBConnectionUtil is properly set up for testing purposes
    }

    // Test case to check user creation
    @Test
    void testCreateUser_Success() {
        User user = new User();
        user.setUsername("testuser");
        user.setPassword("password123");
        user.setEmail("testuser@example.com");

        boolean isUserCreated = financeRepository.createUser(user);
        assertTrue(isUserCreated, "User should be created successfully");
    }

    // Test case to check expense creation
    @Test
    void testCreateExpense_Success() {
        Expense expense = new Expense();
        expense.setUserId(1);  // Assume user with ID 1 exists
        expense.setAmount(150.75);
        expense.setCategoryId(2);  // Assume category with ID 2 exists
        expense.setDate(new Date());
        expense.setDescription("Office Supplies");

        boolean isExpenseCreated = financeRepository.createExpense(expense);
        assertTrue(isExpenseCreated, "Expense should be created successfully");
    }

    // Test case to retrieve all expenses for a user
    @Test
    void testGetAllExpenses_Success() {
        int userId = 1;  // Assume user with ID 1 exists
        List<Expense> expenses = financeRepository.getAllExpenses(userId);

        assertNotNull(expenses, "Expense list should not be null");
        assertTrue(expenses.size() >= 0, "User should have zero or more expenses");
    }

    // Test case to check ExpenseNotFoundException on delete for non-existent expense
    @Test
    void testDeleteExpense_ExpenseNotFoundException() {
        int nonExistentExpenseId = 9999;  // Assume this ID does not exist

        Exception exception = assertThrows(ExpenseNotFoundException.class, () -> {
            boolean result = financeRepository.deleteExpense(nonExistentExpenseId);
            assertFalse(result, "Expense deletion should fail for non-existent expense");
        });

        assertEquals("Expense not found", exception.getMessage());
    }

    // Test case to update non-existent expense and expect failure
    @Test
    void testUpdateExpense_ExpenseNotFoundException() {
        Expense expense = new Expense();
        expense.setExpenseId(9999); // Non-existent expense ID
        expense.setUserId(1);
        expense.setAmount(200);
        expense.setCategoryId(3);
        expense.setDate(new Date());
        expense.setDescription("Updated description");

        boolean isUpdated = financeRepository.updateExpense(1, expense);
        assertFalse(isUpdated, "Expense update should fail for non-existent expense");
    }

    // Test case to delete an existing user
    @Test
    void testDeleteUser() throws UserNotFoundException {
        int existingUserId = 1;  // Assume user with ID 1 exists
        int nonExistentUserId = 9999;  // Assume user with ID 9999 does not exist

        // Test successful deletion
        boolean isUserDeleted = financeRepository.deleteUser(existingUserId);
        assertTrue(isUserDeleted, "User should be deleted successfully");

        // Test deletion of a non-existent user
        isUserDeleted = financeRepository.deleteUser(nonExistentUserId);
        assertFalse(isUserDeleted, "Deleting a non-existent user should return false");
    }


    // Test case to check UserNotFoundException on delete for non-existent user
    @Test
    void testDeleteUser_UserNotFoundException() throws UserNotFoundException {
        int nonExistentUserId = 1;  // Assume this ID does not exist

        // Expect UserNotFoundException when deleting a non-existent user
        UserNotFoundException exception = assertThrows(UserNotFoundException.class, () -> {
            financeRepository.deleteUser(nonExistentUserId);
        });

        assertEquals("User not found", exception.getMessage());
    }}

