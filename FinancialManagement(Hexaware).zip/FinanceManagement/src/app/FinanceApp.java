package app;
import util.DBConnectionUtil;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class FinanceApp {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Connection connection = null;

        try {
            // Establish connection to the database
            connection = DBConnectionUtil.getConnection();

            // Menu-driven application loop
            while (true) {
                System.out.println("==== Finance Management System ====");
                System.out.println("1. Add User");
                System.out.println("2. Add Expense");
                System.out.println("3. Delete User");
                System.out.println("4. Delete Expense");
                System.out.println("5. Update Expense");
                System.out.println("6. Get All Expenses");
                System.out.println("7. Exit");
                System.out.print("Choose an option: ");

                int choice = scanner.nextInt();
                scanner.nextLine(); // Consume newline left-over

                switch (choice) {
                    case 1:
                        addUser(scanner, connection);
                        break;
                    case 2:
                        addExpense(scanner, connection);
                        break;
                    case 3:
                        deleteUser(scanner, connection);
                        break;
                    case 4:
                        deleteExpense(scanner, connection);
                        break;
                    case 5:
                        updateExpense(scanner, connection);
                        break;
                    case 6:
                        getAllExpenses(connection);
                        break;
                    case 7:
                        System.out.println("Exiting the application...");
                        System.exit(0);
                        break;
                    default:
                        System.out.println("Invalid option. Please choose again.");
                }
            }
        } catch (SQLException e) {
            System.out.println("Failed to connect to the database.");
            e.printStackTrace();
        } finally {
            // Close the connection when done
            try {
                if (connection != null && !connection.isClosed()) {
                    connection.close();
                    System.out.println("Database connection closed.");
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }

        scanner.close();
    }

    private static void addUser(Scanner scanner, Connection connection) {
        System.out.print("Enter username: ");
        String username = scanner.nextLine();
        System.out.print("Enter password: ");
        String password = scanner.nextLine();
        System.out.print("Enter email: ");
        String email = scanner.nextLine();

        String query = "INSERT INTO Users (username, password, email) VALUES ('" + username + "', '" + password + "', '" + email + "')";
        try (Statement stmt = connection.createStatement()) {
            stmt.executeUpdate(query);
            System.out.println("User added successfully.");
        } catch (SQLException e) {
            System.out.println("Error adding user: " + e.getMessage());
        }
    }

    private static void addExpense(Scanner scanner, Connection connection) {
        System.out.print("Enter user ID: ");
        int userId = scanner.nextInt();
        System.out.print("Enter amount: ");
        double amount = scanner.nextDouble();
        scanner.nextLine(); // Consume newline
        System.out.print("Enter category ID: ");
        int categoryId = scanner.nextInt();
        scanner.nextLine(); // Consume newline
        System.out.print("Enter date (YYYY-MM-DD): ");
        String expense_date = scanner.nextLine();
        System.out.print("Enter description: ");
        String description = scanner.nextLine();

        String query = "INSERT INTO Expenses (user_id, amount, category_id, expense_date, description) VALUES (" 
                + userId + ", " + amount + ", " + categoryId + ", '" +expense_date + "', '" + description + "')";
        try (Statement stmt = connection.createStatement()) {
            stmt.executeUpdate(query);
            System.out.println("Expense added successfully.");
        } catch (SQLException e) {
            System.out.println("Error adding expense: " + e.getMessage());
        }
    }

    private static void deleteUser(Scanner scanner, Connection connection) {
        System.out.print("Enter user ID to delete: ");
        int userId = scanner.nextInt();

        String query = "DELETE FROM Users WHERE user_id = " + userId;
        try (Statement stmt = connection.createStatement()) {
            int rowsAffected = stmt.executeUpdate(query);
            if (rowsAffected > 0) {
                System.out.println("User deleted successfully.");
            } else {
                System.out.println("User not found.");
            }
        } catch (SQLException e) {
            System.out.println("Error deleting user: " + e.getMessage());
        }
    }

    private static void deleteExpense(Scanner scanner, Connection connection) {
        System.out.print("Enter expense ID to delete: ");
        int expenseId = scanner.nextInt();

        String query = "DELETE FROM Expenses WHERE expense_id = " + expenseId;
        try (Statement stmt = connection.createStatement()) {
            int rowsAffected = stmt.executeUpdate(query);
            if (rowsAffected > 0) {
                System.out.println("Expense deleted successfully.");
            } else {
                System.out.println("Expense not found.");
            }
        } catch (SQLException e) {
            System.out.println("Error deleting expense: " + e.getMessage());
        }
    }

    private static void updateExpense(Scanner scanner, Connection connection) {
        System.out.print("Enter expense ID to update: ");
        int expenseId = scanner.nextInt();
        System.out.print("Enter new amount: ");
        double amount = scanner.nextDouble();
        scanner.nextLine(); // Consume newline
        System.out.print("Enter new description: ");
        String description = scanner.nextLine();

        String query = "UPDATE Expenses SET amount = " + amount + ", description = '" + description + "' WHERE expense_id = " + expenseId;
        try (Statement stmt = connection.createStatement()) {
            int rowsAffected = stmt.executeUpdate(query);
            if (rowsAffected > 0) {
                System.out.println("Expense updated successfully.");
            } else {
                System.out.println("Expense not found.");
            }
        } catch (SQLException e) {
            System.out.println("Error updating expense: " + e.getMessage());
        }
    }

    private static void getAllExpenses(Connection connection) {
        String query = "SELECT * FROM Expenses";
        try (Statement stmt = connection.createStatement();
             ResultSet rs = stmt.executeQuery(query)) {

            System.out.println("=== All Expenses ===");
            while (rs.next()) {
                int expenseId = rs.getInt("expense_id");
                int userId = rs.getInt("user_id");
                double amount = rs.getDouble("amount");
                int categoryId = rs.getInt("category_id");
                String expense_date = rs.getString("expense_date");
                String description = rs.getString("description");

                System.out.printf("Expense ID: %d, User ID: %d, Amount: %.2f, Category ID: %d, Date: %s, Description: %s%n", 
                                  expenseId, userId, amount, categoryId, expense_date, description);
            }
        } catch (SQLException e) {
            System.out.println("Error retrieving expenses: " + e.getMessage());
        }
    }
}
