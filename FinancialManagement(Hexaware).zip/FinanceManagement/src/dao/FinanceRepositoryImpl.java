package dao;

import entity.Expense;

import entity.User;
import exception.UserNotFoundException;
import exception.ExpenseNotFoundException;
import util.DBConnectionUtil;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class FinanceRepositoryImpl implements IFinanceRepository {

    // Method to create a new user in the database
    @Override
    public boolean createUser(User user) {
        String query = "INSERT INTO Users (username, password, email) VALUES (?, ?, ?)";
        try (Connection conn = DBConnectionUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {

            pstmt.setString(1, user.getUsername());
            pstmt.setString(2, user.getPassword());
            pstmt.setString(3, user.getEmail());

            int rowsInserted = pstmt.executeUpdate();
            return rowsInserted > 0; // Return true if user was added successfully

        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    // Method to create a new expense in the database
    @Override
    public boolean createExpense(Expense expense) {
        String query = "INSERT INTO Expenses (user_id, amount, category_id, expense_date, description) VALUES (?, ?, ?, ?, ?)";
        try (Connection conn = DBConnectionUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {

            pstmt.setInt(1, expense.getUserId());
            pstmt.setDouble(2, expense.getAmount());
            pstmt.setInt(3, expense.getCategoryId());
            pstmt.setDate(4, new Date(expense.getDate().getTime()));
            pstmt.setString(5, expense.getDescription());

            int rowsInserted = pstmt.executeUpdate();
            return rowsInserted > 0; // Return true if expense was added successfully

        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    // Method to delete a user from the database
    @Override
    public boolean deleteUser(int userId) throws UserNotFoundException {
        String query = "DELETE FROM Users WHERE user_id = ?";
        try (Connection conn = DBConnectionUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {

            pstmt.setInt(1, userId);
            int rowsDeleted = pstmt.executeUpdate();

            if (rowsDeleted == 0) {
                throw new UserNotFoundException("User not found");
            }
            return true;

        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    
    @Override
    public boolean deleteExpense(int expenseId) {
        String query = "DELETE FROM Expenses WHERE expense_id = ?";
        try (Connection conn = DBConnectionUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {

            pstmt.setInt(1, expenseId);
            int rowsDeleted = pstmt.executeUpdate();
            return rowsDeleted > 0;
            /* if (rowsDeleted == 0)
        	throw new ExpenseNotFoundException("not found")// Return true if expense was deleted successfully
*/


        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

  
    @Override
    public List<Expense> getAllExpenses(int userId) {
        List<Expense> expenses = new ArrayList<>();
        String query = "SELECT * FROM Expenses WHERE user_id = ?";

        try (Connection conn = DBConnectionUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {

            pstmt.setInt(1, userId);
            ResultSet rs = pstmt.executeQuery();

            while (rs.next()) {
                Expense expense = new Expense();
                expense.setExpenseId(rs.getInt("expense_id"));
                expense.setUserId(rs.getInt("user_id"));
                expense.setAmount(rs.getDouble("amount"));
                expense.setCategoryId(rs.getInt("category_id"));
                expense.setDate(rs.getDate("expense_date"));
                expense.setDescription(rs.getString("description"));
                expenses.add(expense);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return expenses; 
    }

   
    @Override
    public boolean updateExpense(int userId, Expense expense) {
        String query = "UPDATE Expenses SET amount = ?, category_id = ?, date = ?, description = ? WHERE user_id = ? AND expense_id = ?";
        try (Connection conn = DBConnectionUtil.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(query)) {

            pstmt.setDouble(1, expense.getAmount());
            pstmt.setInt(2, expense.getCategoryId());
            pstmt.setDate(3, new Date(expense.getDate().getTime()));
            pstmt.setString(4, expense.getDescription());
            pstmt.setInt(5, userId);
            pstmt.setInt(6, expense.getExpenseId());

            int rowsUpdated = pstmt.executeUpdate();
            return rowsUpdated > 0; // Return true if expense was updated successfully

        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
}
