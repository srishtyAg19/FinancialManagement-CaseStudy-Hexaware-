package dao;

import entity.Expense;
import entity.User;
import exception.UserNotFoundException;

import java.util.List;

public interface IFinanceRepository {
    boolean createUser(User user);
    boolean createExpense(Expense expense);
    boolean deleteUser(int userId) throws UserNotFoundException;
    boolean deleteExpense(int expenseId);
    List<Expense> getAllExpenses(int userId);
    boolean updateExpense(int userId, Expense expense);
}
